# class Ave:
# def volar(self):
#return "Estoy volando"

# class Pinguino:
# def volar(self):
#return "No puedo volar"

# delf hacer_volar( ave= Ave):
# return ave.volar(

# print (hacer_volar(Pinguino()))

class Ave:
    pass

class AveVoladora(Ave):
    def volar(delf):
        return "Estoy volando"

class AveNoVoladora(Ave):
    pass
