class Estudiante:
    def_init_(self,nombre,edad,grado):
        self.nombre = nombre
        self.edad =edad
        self.grado = grado


pedro = Estudiante("Pedro",23,3)

print(pedro.edad)